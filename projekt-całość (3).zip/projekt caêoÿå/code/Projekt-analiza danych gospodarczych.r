library(tidyverse)
library(ggrepel)
library(GGally)       
library(fpc)          
library(DataExplorer) 
library(plotly)       
library(FactoMineR)   
library(factoextra)
library(psych)
library(corrplot)
library(pander)
library(ggplot2)
library(viridis)
library(ggplot2)
library(cluster)
library(leaps)

proj <- read.csv2("./data/PROJEKT.csv")
summary(proj)
proj %>% 
  ggplot(aes(x=PKB))+
  geom_boxplot(fill= "lightblue")+xlab("PKB")+theme_bw()
proj %>% 
  ggplot(aes(x=Zwolnienia.ze.szpitala))+
  geom_boxplot(fill= "paleturquoise4")+xlab("Zwolnienia z przyczyn kardiologicznych")+theme_bw()
proj %>% 
  ggplot(aes(x=Użycie.Internetu))+
  geom_boxplot(fill= "lightyellow")+xlab("Użycie internetu")+theme_bw()
proj %>% 
  ggplot(aes(x=Budżet.na.rozwój))+
  geom_boxplot(fill= "lightpink")+xlab("Budżet na badania i rozwój")+theme_bw()
proj %>% 
  ggplot(aes(x= Produkcja.energii))+
  geom_boxplot(fill= "lightsalmon1")+xlab("Produkcja energii")+theme_bw()

proj %>% 
  ggplot(aes(x= Wydajność.pracowników))+
  geom_boxplot(fill= "wheat3")+xlab("Wydajność pracowników")+theme_bw()

proj %>% 
ggplot(aes(x= Zarobki.roczne ))+
  geom_boxplot(fill= "lightpink3")+xlab("Zarobki.roczne")+theme_bw()

proj %>% 
  ggplot(aes(x= Wskaźnik.konsumpcji ))+
  geom_boxplot(fill= "honeydew3")+xlab("Wskaźnik konsupcji")+theme_bw()


#efekt 4
proj <- read.csv2("./data/PROJEKT.csv")
proj <- proj[-2]
cor(proj[, 2:8])
corrplot(cor(proj[, 2:8]), order = "hclust", tl.cex = 0.7, col = COL1('Purples'), tl.col = 'black')
cortest.bartlett(cor(proj[, 2:8]), n = nrow(proj))
KMO(cor(proj[, 2:8]))
pr1 <- principal(proj[, 2:8], nfactors = 2, rotate = "none")
plot(pr1$values, type="b") #wykres osypiska
abline(h=1, col="red") 
plot(cumsum(pr1$values)/8, type="b") #Wizualizacja procentu wyjaśnianej wariancji dla różnej liczby składowych

proj <- proj %>% select(-Kraj)
pr2 <- PCA(proj, graph = FALSE) 
fviz_screeplot(pr2, addlabels = TRUE, barfill = "turquoise4",
               barcolor="goldenrod", xlab = "", ylab = "")+theme_bw() 

#efekt 5
proj <- read.csv2("./data/PROJEKT.csv")
proj <- proj[-2]
proj.scaled <- scale(proj[, 2:8]) %>% as.data.frame()

#grupowanie metodą Warda
# hclust
clusterboot(proj.scaled, B = 500,
            clustermethod = hclustCBI, method = "ward.D2", k = 2)

clusterboot(proj.scaled, B = 500,
            clustermethod = hclustCBI, method = "ward.D2", k = 4)

#Zastosowałyśmy metodę hclust, ponieważ jest ona bardzo stabilna
#Poniżej sprawdzimy na ile grup powinniśmy podzielić

fviz_nbclust(proj.scaled, clara, method = "wss") #2
fviz_nbclust(proj.scaled, clara, method = "silhouette") #2
fviz_nbclust(proj.scaled, clara, method = "gap_stat") #1

#Podsumowując najlepiej wybrać dwie grupy
clara1 <- clara(proj.scaled, k = 2)
fviz_cluster(clara1, data = proj.scaled, repel = TRUE, labelsize = 8, ggtheme = theme_bw())

#Według grupowania algorytmem clara pierwszy wymiar przyjmuje wartości ujemne dla wysoko rozwiniętych krajów, a dodatnie dla mniej rozwiniętych.
summary(proj.scaled) 
rownames(proj.scaled) <- proj$Kraj
p <- dist(proj.scaled, method = "euclidean")
hc1 <- hclust(p, method = "ward.D2")

#Wyświetlenie dendrogramu - plot na obiekcie hclust.

fviz_dend(hc1, cex = 0.7, lwd = 0.7, main = "Dendrogram Państw", xlab = "Państwa", k = 2, k_colors = 
            c("darkorchid","mediumaquamarine"), ggtheme = theme_bw(), rect = TRUE)


#Najbliżej siebie są Czechy i Estonia.

#Odległość na wykresie tych dwóch zmiennych od siebie jest najmniejsza.

#Odczytujemy to na podstawie dendrogramu i najniżej położonej kreski łączącej pary.

#Dendrogram wyraźnie wyznacza dwie grupy. Odczytujemy go metodą "bottom up", czyli od dołu.

#Dzielimy nasz zbiór na dwie grupy i odczytujemy, która grupa ma przewagę dla poszczególnych zmiennych.

#Wizualizacja Państw i ich umiejscowienie na biplocie 
cutree(hc1, k = 2)
proj$cluster.w <- cutree(hc1, k = 2) %>% as.factor()
plot_boxplot(proj[, 2:9], by = "cluster.w", 
             geom_boxplot_args = list(fill = "turquoise4", "outlier.color" = "goldenrod"), ggtheme = theme_bw())

pr <- proj %>% 
  select(-Kraj)
rownames(pr) <- proj$Kraj
pc1 <- PCA(pr, quali.sup = 8, graph = FALSE)
fviz_pca_biplot(pc1, habillage = 8, legend = "bottom", col.var = "turquoise4",labelsize = 3)
fviz_pca_ind(pc1, habillage = 8, legend = "bottom",labelsize = 3,addEllipses =TRUE)

#Zgodnie z metodą Warda, odwrotnie niż algorytmem Clara, grupowanie przypisało dodatnie wartości wymiaru 1 Państwom lepiej rozwniętym.
#Zarysowane grupy są jednak do siebie bardzo zbliżone.
#Większe odchylenia można zauważyć w grupie 1, w grupie 2 większość Państw ma zbliżone do siebie wyniki.

#efekt 6

proj <- read.csv2("./data/PROJEKT.csv")
proj <- proj[-1]
str(proj)

# seed
set.seed(20)

# wielkosc zbioru testowego
p.test <- 0.2

# losowanie numerow wierszy w zbiorze testowym
test.ind <- sample.int(nrow(proj), size = trunc(p.test * nrow(proj)))

# zbiory: testowy (bos.test) i treningowy (bos.train)
proj.test <- proj[test.ind, ]
proj.train <- proj[-test.ind, ]
rs <- regsubsets(PKB ~ ., data =proj, nvmax= 8, method= "seqrep")
plot(rs, scale ="adjr2", col = c("darkgreen","green4","palegreen3"), labels = FALSE)
text(x = 1:length(proj),
     y = par("usr")[3] - 0.45,
     labels = names(proj),
     xpd = NA,
     srt = 18,
     cex = 0.8)

lm01 <- lm(PKB~., data = proj)
lm01

#Regresja z udziałem wymiarów

proj <- read.csv2("./data/PROJEKT.csv")
proj <- proj[c(-1,-2)]
summary(proj)

pr2 <- principal(proj, nfactors=2, rotate="none") 
pr2$scores 
df <- as.data.frame(pr2$scores) 
proj <- read.csv2("./data/PROJEKT.csv")
df$y1=proj$PKB 
df

model1 <- lm(df$y1~df$PC1)
summary(model1)

#wymiar 1 pc1 wyjaśnia 90% zmiennej celu PKB
#Parametry modelu są istotne obie wartości p value są mniejsze od 0,05 
#2
model2 <- lm(df$y1~df$PC1+df$PC2)
summary(model2) 
#Także uzyskano istotny model F statistic, wyjaśnia 90% zmienności zmiennej PKB. PC2 za to okazało się nieistotne

anova(model1, model2)
#Przyjmujemy hipotezę
#H0: oba modele są równie przydatne do przewidywania wyniku 
#Wniosek:Oba modele mogą być wykorzystane, niewiele się różnią od siebie

#Dodatkowe analizy:
#Połączenie PCA i analizy skupień